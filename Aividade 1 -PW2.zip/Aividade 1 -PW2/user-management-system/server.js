const express = require('express'); 
const bodyParser = require('body-parser');
const { User } = require('./models'); 

const app = express();
app.set('view engine', 'ejs'); 

app.use(bodyParser.urlencoded({ extended: true })); 

app.get('/register', (req, res) => {
  res.render('register'); 
});

app.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    await User.create({ name, email, password }); 
    res.redirect('/users'); 
  } catch (error) {
    res.send('Erro ao criar usuário');
  }
});

app.get('/users', async (req, res) => {
  try {
    const users = await User.findAll(); 
    res.render('users', { users }); 
  } catch (error) {
    res.send('Erro ao carregar a lista de usuários'); 
  }
});

app.post('/delete/:id', async (req, res) => {
  try {
    await User.destroy({ where: { id: req.params.id } }); 
    res.redirect('/users'); 
  } catch (error) {
    res.send('Erro ao remover usuário'); 
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
